<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
    
$mail = new PHPMailer(); // create a new object
$mail->CharSet = 'UTF-8';
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "quentin.lignani.schuman@gmail.com";
$mail->Password = "Admwb2000";
$mail->SetFrom("q.lignani@lprs.fr");
$mail->Subject = "[Robert Schuman] : ";
$mail->Body = "<center><b>Réservation au Snack</b></center><br><center><p>Bonjour ! Mangez-vous au Snack cette semaine ?</p></center>";
$mail->AddAddress("q.lignani@lprs.fr");

 if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo "Message has been sent";
 }